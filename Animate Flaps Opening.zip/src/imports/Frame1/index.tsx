import imgEnvelopeFlapRight1 from "./3d7ff47a39a282b7d21b7d3508ca5d79ee029be4.png";
import imgEnvelopeFlapLeft1 from "./b5aa788a541650819cffc7d7a5fbcf36292dfd5f.png";
import imgEnvelopeFlapTop1 from "./b25089513302b426dd1763ad46155890ac591c98.png";
import imgEnvelopeFlapBottom1 from "./15dc4b00272ffede9c92b55d0dded4734583f266.png";
import imgWaxSealGold1 from "./370785aeab1e8a43a220648251f4b6b997ed9ba5.png";

export default function Frame() {
  return (
    <div className="bg-white relative size-full">
      <div className="absolute h-[628px] left-[177px] top-[111px] w-[225px]" data-name="envelope-flap-right 1">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgEnvelopeFlapRight1} />
      </div>
      <div className="absolute h-[654px] left-0 top-[99px] w-[193px]" data-name="envelope-flap-left 1">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgEnvelopeFlapLeft1} />
      </div>
      <div className="absolute h-[602px] left-0 top-[-106px] w-[402px]" data-name="envelope-flap-top 1">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgEnvelopeFlapTop1} />
      </div>
      <div className="absolute h-[616px] left-0 top-[387px] w-[402px]" data-name="envelope-flap-bottom 1">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgEnvelopeFlapBottom1} />
      </div>
      <div className="absolute left-[128px] size-[155px] top-[362px]" data-name="wax-seal-gold 1">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgWaxSealGold1} />
      </div>
    </div>
  );
}