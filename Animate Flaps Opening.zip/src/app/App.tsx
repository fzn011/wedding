import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import imgEnvelopeFlapRight from "../imports/Frame1/3d7ff47a39a282b7d21b7d3508ca5d79ee029be4.png";
import imgEnvelopeFlapLeft from "../imports/Frame1/b5aa788a541650819cffc7d7a5fbcf36292dfd5f.png";
import imgEnvelopeFlapTop from "../imports/Frame1/b25089513302b426dd1763ad46155890ac591c98.png";
import imgEnvelopeFlapBottom from "../imports/Frame1/15dc4b00272ffede9c92b55d0dded4734583f266.png";
import imgWaxSeal from "../imports/Frame1/370785aeab1e8a43a220648251f4b6b997ed9ba5.png";

export default function App() {
  const [opened, setOpened] = useState(false);

  return (
    <div className="size-full flex items-center justify-center bg-[#f5f0e8]">
      <div className="relative" style={{ width: 402, height: 750 }}>

        {/* Envelope body background */}
        <div
          className="absolute inset-0 rounded-sm"
          style={{ background: "linear-gradient(135deg, #f9f5ee 0%, #ede8de 100%)" }}
        />

        {/* Right flap */}
        <AnimatePresence>
          {!opened && (
            <motion.div
              key="right"
              className="absolute"
              style={{ height: 628, left: 177, top: 111, width: 225, originX: 0, originY: 0.5 }}
              exit={{ x: 280, opacity: 0, transition: { duration: 0.55, ease: [0.4, 0, 0.2, 1] } }}
            >
              <img
                alt=""
                className="absolute inset-0 max-w-none object-cover pointer-events-none size-full"
                src={imgEnvelopeFlapRight}
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Left flap */}
        <AnimatePresence>
          {!opened && (
            <motion.div
              key="left"
              className="absolute"
              style={{ height: 654, left: 0, top: 99, width: 193, originX: 1, originY: 0.5 }}
              exit={{ x: -240, opacity: 0, transition: { duration: 0.55, ease: [0.4, 0, 0.2, 1] } }}
            >
              <img
                alt=""
                className="absolute inset-0 max-w-none object-cover pointer-events-none size-full"
                src={imgEnvelopeFlapLeft}
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Top flap */}
        <AnimatePresence>
          {!opened && (
            <motion.div
              key="top"
              className="absolute"
              style={{ height: 602, left: 0, top: -106, width: 402, originX: 0.5, originY: 1 }}
              exit={{ y: -320, opacity: 0, transition: { duration: 0.55, ease: [0.4, 0, 0.2, 1] } }}
            >
              <img
                alt=""
                className="absolute inset-0 max-w-none object-cover pointer-events-none size-full"
                src={imgEnvelopeFlapTop}
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Bottom flap */}
        <AnimatePresence>
          {!opened && (
            <motion.div
              key="bottom"
              className="absolute"
              style={{ height: 616, left: 0, top: 387, width: 402, originX: 0.5, originY: 0 }}
              exit={{ y: 320, opacity: 0, transition: { duration: 0.55, ease: [0.4, 0, 0.2, 1] } }}
            >
              <img
                alt=""
                className="absolute inset-0 max-w-none object-cover pointer-events-none size-full"
                src={imgEnvelopeFlapBottom}
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Wax seal — the clickable gold button */}
        <motion.button
          className="absolute cursor-pointer focus:outline-none"
          style={{ left: 128, top: 362, width: 155, height: 155 }}
          onClick={() => setOpened(true)}
          whileHover={!opened ? { scale: 1.06 } : {}}
          whileTap={!opened ? { scale: 0.96 } : {}}
          animate={opened ? { scale: 0, opacity: 0, transition: { delay: 0.3, duration: 0.35 } } : { scale: 1, opacity: 1 }}
          aria-label="Open envelope"
        >
          <img
            alt="Wax seal — tap to open"
            className="absolute inset-0 max-w-none object-cover pointer-events-none size-full"
            src={imgWaxSeal}
          />
        </motion.button>

        {/* Opened state: inner content reveal */}
        <AnimatePresence>
          {opened && (
            <motion.div
              key="inner"
              className="absolute inset-0 flex flex-col items-center justify-center gap-4 px-10"
              initial={{ opacity: 0, scale: 0.85 }}
              animate={{ opacity: 1, scale: 1, transition: { delay: 0.5, duration: 0.5, ease: [0.22, 1, 0.36, 1] } }}
            >
              <p
                className="text-center font-serif text-[#8a7250] tracking-widest uppercase text-xs"
                style={{ fontFamily: "Georgia, serif", letterSpacing: "0.25em" }}
              >
                You have a message
              </p>
              <div
                className="w-full border-t"
                style={{ borderColor: "#c9b898" }}
              />
              <p
                className="text-center text-[#5a4a38] leading-relaxed text-sm"
                style={{ fontFamily: "Georgia, serif" }}
              >
                بسم الله الرحمن الرحيم
              </p>
              <motion.button
                className="mt-4 px-6 py-2 rounded-full text-xs tracking-widest uppercase"
                style={{
                  background: "linear-gradient(135deg, #d4a843 0%, #b8892a 100%)",
                  color: "#fff",
                  fontFamily: "Georgia, serif",
                  letterSpacing: "0.2em",
                  boxShadow: "0 2px 12px rgba(180,140,40,0.35)",
                }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => setOpened(false)}
              >
                Close
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
