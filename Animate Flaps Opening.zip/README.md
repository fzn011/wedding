
  # Animate Flaps Opening

  This is a code bundle for Animate Flaps Opening. The original project is available at https://www.figma.com/design/zBW0jZmETTwBQFV57cfySW/Animate-Flaps-Opening.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  